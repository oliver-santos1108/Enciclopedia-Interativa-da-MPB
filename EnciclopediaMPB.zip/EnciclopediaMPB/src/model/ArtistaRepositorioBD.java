package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
		/**
		 * MODEL - guarda os animais no MySQL e aplica a regra do conjunto.
		 *
		 * PASSO 6 do roteiro. Repare que ele tem os MESMOS metodos que a versao
		 * em memoria do Passo 5: salvar, listarTodos, contar. So mudou o destino.
		 *
		 * Procure "javax.swing" neste arquivo: nao ha nenhum. E por isso que da
		 * para testar esta classe sem abrir tela.
		 */
		public class ArtistaRepositorioBD {
		 // Os tres dados da conexao num lugar so.
		 private static final String URL = "jdbc:mysql://localhost:3306/meusistema";
		 private static final String USER = "aluno_cd";
		 private static final String SENHA = "aluno_pw";
		 // Conexao NOVA a cada chamada. Uma conexao guardada em atributo e
		 // derrubada pelo servidor por inatividade, e a aplicacao para de
		 // funcionar ate ser reiniciada.
		 private Connection abrir() throws SQLException {
		 return DriverManager.getConnection(URL, USER, SENHA);
		 }
		 public void salvar(Artista a) {
		 // 1. as regras do animal sozinho, ja escritas no Model
			 //PASSO 5 PEDENDENTE - ArtistaRepositorio
		 String problema = a.validarArtista();
		 if (problema != null) {
		 throw new IllegalArgumentException(problema);
		 }
		 // 2. a regra que depende dos OUTROS registros - ArtistaRepositorio
		 if (existe(a.getNome(), a.getAlbuns())) { //nao funcionaria pois ex: Rita Lee tem 2 albuns com o mesmo nome
		 throw new IllegalArgumentException(
		 "Este dono ja tem um animal com esse nome.");
		 }
		 String sql = "INSERT INTO artista (nome, data_nascimento, conjuges, quant_albuns, albuns, data_falecimento, idade, local_nascimento) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		 try (Connection con = abrir();
				 
				 
				 
			PreparedStatement ps = con.prepareStatement(sql)) {
			 // Um set por campo, na ORDEM das colunas do INSERT.
			 // Indices comecam em 1. O tipo do set combina com o tipo do
			 // atributo: setString para texto, setDouble para decimal.
			 ps.setString(1, a.getNome().trim());
			 ps.setInt(2, a.getData_nascimento());
			 ps.setString(3, a.getConjuges().trim());
			 ps.setString(4, a.getConjuges().trim());
			 ps.setInt(5, a.getQuant_albuns());
			 ps.setString(6, a.getAlbuns().trim());
			 ps.setInt(7, a.getData_falecimento());
			 ps.setInt(8, a.getIdade());
			 ps.setString(9, a.getLocal_nascimento().trim());
			 ps.executeUpdate();
			 
			 } catch (SQLException erro) {
			 throw new RuntimeException("Erro ao gravar: " + erro.getMessage(), erro);
			 }
			 }
			 public boolean existe(String nome, String albuns) {
			 String sql = "SELECT id FROM artista WHERE nome = ? AND album = ?";
			 try (Connection con = abrir();
			 PreparedStatement ps = con.prepareStatement(sql)) {
			 ps.setString(1, nome.trim());
			 ps.setString(2, albuns.trim());
			 try (ResultSet rs = ps.executeQuery()) {
			 return rs.next(); // achou pelo menos uma linha?
			 }
			 } catch (SQLException erro) {
			 throw new RuntimeException("Erro ao consultar: " + erro.getMessage(),
			erro);
			 }
			 }
		
			 public List<Artista> listarTodos() {
			 String sql = "SELECT nome, data_nascimento, conjuges, quant_albuns, String albuns, data_falecimento, int idade, String local_nascimento FROM artista ORDER BY nome";
			 List<Artista> lista = new ArrayList<>();
			 try (Connection con = abrir();
			 PreparedStatement ps = con.prepareStatement(sql);
			 ResultSet rs = ps.executeQuery()) {
			 while (rs.next()) {
			 // Um get por coluna, alimentando um set do objeto.
			 // getString para VARCHAR, getDouble para DECIMAL.
			 Artista a = new Artista();
			 a.setNome(rs.getString("Rita Lee"));
			 a.setData_nascimento(rs.getInt("1947"));
			 a.setConjuges(rs.getString("Roberto de Carvalho"));
			 a.setQuant_albuns(rs.getInt("30"));
			 a.setAlbuns(rs.getString("Fruto Proibido"));
			 a.setData_falecimento(rs.getInt(2023));
			 a.setIdade(rs.getInt(75));
			 a.setLocal_nascimento(rs.getString("São Paulo"));
			 lista.add(a);
			 }
			 
			 } catch (SQLException erro) {
			 throw new RuntimeException("Erro ao listar: " + erro.getMessage(), erro);
			 }
			 return lista;
			 }
			 public int contar() {
			 String sql = "SELECT COUNT(*) FROM artista";
			 
			 try (Connection con = abrir();
					 PreparedStatement ps = con.prepareStatement(sql);
					 ResultSet rs = ps.executeQuery()) {
					 if (rs.next()) {
					 return rs.getInt(1); // primeira coluna do resultado
					 }
					 return 0;
					 } catch (SQLException erro) {
					 throw new RuntimeException("Erro ao contar: " + erro.getMessage(), erro);
					 }
					 }
					 /** Teste de ambiente: rode ANTES de depurar qualquer botao. */
					 public static void main(String[] args) {
					 ArtistaRepositorioBD bd = new ArtistaRepositorioBD();
					 try (Connection con = bd.abrir()) {
					 System.out.println("Conexao OK com " + con.getCatalog());
					 System.out.println("Registros: " + bd.contar());
					 } catch (SQLException e) {
					 System.out.println("Falha: " + e.getMessage());
					 }

	}

}
