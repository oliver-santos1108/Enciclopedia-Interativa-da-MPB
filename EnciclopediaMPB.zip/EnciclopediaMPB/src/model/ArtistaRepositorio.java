package model;

import java.util.ArrayList;
import java.util.List;

//Passo 5 pendente - preciso pensar nas regras
public class ArtistaRepositorio {
	
	private List<Artista> artistas = new ArrayList<>();
	public void salvar(Artista a) {
		String problema = a.validarArtista();
		if (problema != null) {
			throw new IllegalArgumentException(problema);
		}
		
		 if (existe(a.getNome(), a.getData_nascimento())) {
			 throw new IllegalArgumentException(
			 "Já existe um artista cadastrado com esse nome e data de nascimento");
			 }
		
		artistas.add(a);

	}
	

	public List<Musica> musicas = new ArrayList<>();
	public List<Album> albuns = new ArrayList<>();
	
	

	/*public class AnimalRepositorio {
 private List<Animal> animais = new ArrayList<>();
 public void salvar(Animal a) {
 // 1. as regras do objeto sozinho, ja escritas no Model
 String problema = a.validar();
 if (problema != null) {
 throw new IllegalArgumentException(problema);
 }
 // 2. a regra que depende dos OUTROS registros
 if (existe(a.getNome(), a.getDono())) {
 throw new IllegalArgumentException(
 "Este dono ja tem um animal com esse nome.");
 }
 // 3. so agora grava: valide antes de alterar o estado
 animais.add(a);
 }
 public boolean existe(String nome, String dono) {
 for (Animal a : animais) {
 // equals e nao ==: a pergunta e sobre CONTEUDO
 if (a.getNome().equals(nome) && a.getDono().equals(dono)) {
 return true;
 }
 }
 return false;
 }
 public List<Animal> listarTodos() {
 // devolve uma COPIA: ninguem altera a colecao interna por fora
 return new ArrayList<>(animais);
 }
 public int contar() {
 return animais.size();
 }
}
*/
	
}
